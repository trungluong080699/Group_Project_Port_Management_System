
public class WelcomeScreen {
    public static void displayWelcomeScreen() {
        System.out.println("**********************************************");
        System.out.println("        COSC2081 GROUP ASSIGNMENT");
        System.out.println("CONTAINER PORT MANAGEMENT SYSTEM");
        System.out.println("Instructor: Mr. Minh Vu & Dr. Phong Ngo");
        System.out.println("Group: Group 1");
        System.out.println("s3979381, Tran Dang Duong");
        System.out.println("s3864219, Mai Chi Nghi");
        System.out.println("s3679813, Luong Thanh Trung");
        System.out.println("s3978175, Nguyen Pham Tan Hau");
        System.out.println("**********************************************");
    }

    public static void main(String[] args) {
        displayWelcomeScreen();
    }
}
