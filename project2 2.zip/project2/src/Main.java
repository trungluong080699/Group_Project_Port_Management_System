import Container_Class.Container;
import Container_Class.Dry_Storage;
import FileIO.FileIOUtil;
import Port.Port;
import Trip.Trip;
import Users.Port_Manager;
import Users.System_Admin;
import Users.Utlity;
import Vehicle_Classes.Vehicle;

import java.io.*;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;


public class Main {
    public static void main(String[] args) throws IOException {

        //System_Admin admin2 = new System_Admin("1234567890", "adminUser", "adminPass", "Admin");
        //"eid":"5133826291","username":"TrungLuong0806","password":"1234567890","role":"Port Manager","port":"0357395486"
        //"eid":"2277394957","username":"Testing Manager","password":"1234567890","role":"Port Manager","port":"0827061974"


        Menu.program_Run();













    }
}

